let mwaka=prompt("whats your name?")
alert(`you are ${mwaka}`)


let webDR= confirm("Are you a web developer?")
alert("webDR")